-- response-data.sql
INSERT INTO responses (id,question_id,answer_text) VALUES (4,4,'Yes');
INSERT INTO responses (id,question_id,answer_text) VALUES (5,5,'No');
