package com.example.backend.service;

import com.example.backend.DTO.UserDto;

public interface UserServiceInter {
    String registerUser(UserDto userDTO);
}
